﻿namespace $safeprojectname$.ViewModels
{
    using Catel;
    using Catel.MVVM;
    using Catel.Services;
    using System.Threading.Tasks;

    public class MainPageViewModel : ViewModelBase
    {
        private readonly INavigationService _navigationService;

        public MainPageViewModel(INavigationService navigationService)
        {
            Argument.IsNotNull(() => navigationService);
            
            _navigationService = navigationService;
        
            TestNavigation = new Command(OnTestNavigationExecute);
        }

        public override string Title { get { return "$safeprojectname$"; } }

        public Command TestNavigation { get; private set; }

        private void OnTestNavigationExecute()
        {
            _navigationService.Navigate<SecondViewModel>();
        }
        
        // TODO: Register models with the vmpropmodel codesnippet
        // TODO: Register view model properties with the vmprop or vmpropviewmodeltomodel codesnippets
        // TODO: Register commands with the vmcommand or vmcommandwithcanexecute codesnippets
        
        protected override async Task Initialize()
        {
            await base.Initialize();

            // TODO: subscribe to events here
        }

        protected override async Task Close()
        {
            // TODO: unsubscribe from events here

            await base.Close();
        }         
    }
}
