﻿namespace $safeprojectname$.ViewModels
{
    using Catel.MVVM;

    /// <summary>
    /// Second view model.
    /// </summary>
    public class SecondViewModel : NavigationViewModelBase
    {
        #region Constructors
        /// <summary>
        /// Initializes a new instance of the <see cref="SecondViewModel"/> class.
        /// </summary>
        public SecondViewModel()
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets the title of the view model.
        /// </summary>
        /// <value>The title.</value>
        public override string Title { get { return "Second view model"; } }
        #endregion

        #region Commands
        // TODO: Register commands with the vmcommand or vmcommandwithcanexecute codesnippets
        #endregion

        #region Methods
        #endregion
    }
}
