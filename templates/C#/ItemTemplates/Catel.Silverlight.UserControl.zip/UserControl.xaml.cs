﻿namespace $rootnamespace$
{
    using Catel.Windows.Controls;

    /// <summary>
    /// Interaction logic for $safeitemname$.xaml.
    /// </summary>
    public partial class $safeitemname$ : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="$safeitemname$"/> class.
        /// </summary>
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}
