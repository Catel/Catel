﻿namespace $rootnamespace$
{
	using Catel.Phone.Controls;

    /// <summary>
    /// Interaction logic for $safeitemname$.xaml.
    /// </summary>
    public partial class $safeitemname$ : PhoneApplicationPage
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="$safeitemname$"/> class.
        /// </summary>
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}