﻿namespace $rootnamespace$
{
    public sealed partial class $safeitemname$
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}