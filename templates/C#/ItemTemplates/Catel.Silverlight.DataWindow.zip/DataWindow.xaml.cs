﻿namespace $rootnamespace$
{
    using Catel.Windows;
    using ViewModels;

    public partial class $safeitemname$
    {
        public $safeitemname$()
            : this(null) { }    

        public $safeitemname$($safeitemname$Model viewModel)
            : base(viewModel)
        {
            InitializeComponent();
        }    
    }
}