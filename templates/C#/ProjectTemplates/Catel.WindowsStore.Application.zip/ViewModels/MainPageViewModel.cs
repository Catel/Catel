﻿namespace $safeprojectname$.ViewModels
{
    using Catel.MVVM;
    using Catel.MVVM.Services;

    /// <summary>
    /// MainWindow view model.
    /// </summary>
    public class MainPageViewModel : ViewModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MainPageViewModel"/> class.
        /// </summary>
        public MainPageViewModel()
        {
            TestNavigation = new Command(OnTestNavigationExecute);
        }

        /// <summary>
        /// Gets the title of the view model.
        /// </summary>
        /// <value>The title.</value>
        public override string Title { get { return "My application"; } }

        /// <summary>
        /// Gets the TestNavigation command.
        /// </summary>
        public Command TestNavigation { get; private set; }

        /// <summary>
        /// Method to invoke when the TestNavigation command is executed.
        /// </summary>
        private void OnTestNavigationExecute()
        {
            var navigationService = GetService<INavigationService>();
            navigationService.Navigate<SecondViewModel>();
        }
    }
}
