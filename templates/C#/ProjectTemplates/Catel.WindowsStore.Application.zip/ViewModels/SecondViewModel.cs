﻿namespace $safeprojectname$.ViewModels
{
    using Catel.MVVM;

    /// <summary>
    /// Second view model.
    /// </summary>
    public class SecondViewModel : NavigationViewModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SecondViewModel"/> class.
        /// </summary>
        public SecondViewModel()
        {
        }

        /// <summary>
        /// Gets the title of the view model.
        /// </summary>
        /// <value>The title.</value>
        public override string Title { get { return "Second view model"; } }
    }
}
