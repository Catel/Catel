﻿namespace $safeprojectname$.ViewModels
{
	using Catel.MVVM;

    /// <summary>
    /// MainPageViewModel view model.
    /// </summary>
    public class MainPageViewModel : ViewModelBase
    {
		#region Fields
		#endregion
	
        #region Constructors
        /// <summary>
        /// Initializes a new instance of the <see cref="MainPageViewModel"/> class.
        /// </summary>
        public MainPageViewModel()
            : base()
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets the title of the view model.
        /// </summary>
        /// <value>The title.</value>
        public override string Title { get { return "View model title"; } }

		// TODO: Register models with the vmpropmodel codesnippet
		// TODO: Register view model properties with the vmprop or vmpropviewmodeltomodel codesnippets
		#endregion

		#region Commands
		// TODO: Register commands with the vmcommand or vmcommandwithcanexecute codesnippets
		#endregion

		#region Methods
        /// <summary>
        /// Called when the navigation has completed.
        /// </summary>
        /// <remarks>
        /// This should of course be a cleaner solution, but there is no other way to let a view-model
        /// know that navigation has completed. Another option is injection, but this would require every
        /// view-model for Windows Phone 7 to accept only the navigation context, which has actually nothing
        /// to do with the logic.
        /// <para/>
        /// It is also possible to use the <see cref="NavigationCompleted"/> event.
        /// </remarks>
        protected override void OnNavigationCompleted()
        {
			// TODO: Handle arguments that are now in NavigationContext
        }
		#endregion
    }
}
