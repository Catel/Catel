﻿namespace $safeprojectname$.ViewModels
{
	using Catel.MVVM;

    /// <summary>
    /// MainWindow view model.
    /// </summary>
    public class MainWindowViewModel : ViewModelBase
    {
		#region Fields
		#endregion
	
        #region Constructors
        /// <summary>
        /// Initializes a new instance of the <see cref="MainWindowViewModel"/> class.
        /// </summary>
        public MainWindowViewModel()
            : base()
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets the title of the view model.
        /// </summary>
        /// <value>The title.</value>
        public override string Title { get { return "View model title"; } }

		// TODO: Register models with the vmpropmodel codesnippet
		// TODO: Register view model properties with the vmprop or vmpropviewmodeltomodel codesnippets
		#endregion

		#region Commands
		// TODO: Register commands with the vmcommand or vmcommandwithcanexecute codesnippets
		#endregion

		#region Methods
		// TODO: Create your methods here
		#endregion
    }
}
