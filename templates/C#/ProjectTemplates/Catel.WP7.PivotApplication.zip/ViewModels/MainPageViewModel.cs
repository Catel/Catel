﻿namespace $safeprojectname$.ViewModels
{
	using System.Collections.Generic;
	using System.Collections.ObjectModel;
	
	using Catel.Data;
	using Catel.MVVM;
	using Catel.MVVM.Services;
	
	using Models;

    public class MainPageViewModel : ViewModelBase
    {
		#region Fields
		#endregion
		
        #region Constructors
        /// <summary>
        /// Initializes a new instance of the <see cref="MainPageViewModel"/> class.
        /// </summary>
        public MainPageViewModel()
            : base()
        {
			Items = new ObservableCollection<ItemData>();
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets the title of the view model.
        /// </summary>
        /// <value>The title.</value>
        public override string Title { get { return "Page title"; } }

        // TODO: Register models with the vmpropmodel codesnippet
        // TODO: Register view model properties with the vmprop or vmpropviewmodeltomodel codesnippets
		
        /// <summary>
        /// Gets or sets the collection of items.
        /// </summary>
        public ObservableCollection<ItemData> Items
        {
            get { return GetValue<ObservableCollection<ItemData>>(ItemsProperty); }
            private set { SetValue(ItemsProperty, value); }
        }

        /// <summary>
        /// Register the Items property so it is known in the class.
        /// </summary>
        public static readonly PropertyData ItemsProperty = RegisterProperty("Items", typeof(ObservableCollection<ItemData>));		
        #endregion

        #region Commands
        // TODO: Register commands with the vmcommand or vmcommandwithcanexecute codesnippets
        #endregion

        #region Methods
        #endregion
    }
	
    public class DesignMainPageViewModel : MainPageViewModel
    {
		public DesignMainPageViewModel()
		{
            // Design data
            Items.Add(new ItemData("Design data 1"));
            Items.Add(new ItemData("Design data 2"));
            Items.Add(new ItemData("Design data 3"));
            Items.Add(new ItemData("Design data 4"));
            Items.Add(new ItemData("Design data 5"));		
		}
    }	
}