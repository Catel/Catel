﻿namespace $safeprojectname$.ViewModels
{
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    
    using Catel.Data;
    using Catel.MVVM;
    using Catel.Services;
    
    using Models;

    public class MainPageViewModel : ViewModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MainPageViewModel"/> class.
        /// </summary>
        public MainPageViewModel()
        {
            Items = new ObservableCollection<ItemData>();
        }

        /// <summary>
        /// Gets the title of the view model.
        /// </summary>
        /// <value>The title.</value>
        public override string Title { get { return "$safeprojectname$"; } }

        /// <summary>
        /// Gets or sets the collection of items.
        /// </summary>
        public ObservableCollection<ItemData> Items
        {
            get { return GetValue<ObservableCollection<ItemData>>(ItemsProperty); }
            private set { SetValue(ItemsProperty, value); }
        }

        /// <summary>
        /// Register the Items property so it is known in the class.
        /// </summary>
        public static readonly PropertyData ItemsProperty = RegisterProperty("Items", typeof(ObservableCollection<ItemData>));        
    }
    
    public class DesignMainPageViewModel : MainPageViewModel
    {
        public DesignMainPageViewModel()
        {
            // Design data
            Items.Add(new ItemData("Design data 1"));
            Items.Add(new ItemData("Design data 2"));
            Items.Add(new ItemData("Design data 3"));
            Items.Add(new ItemData("Design data 4"));
            Items.Add(new ItemData("Design data 5"));        
        }
    }    
}