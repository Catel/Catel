﻿namespace $safeprojectname$.Views
{
    using Catel.Windows.Controls;
    
    /// <summary>
    /// Interaction logic for About.xaml.
    /// </summary>
    public partial class About : Page
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="About"/> class.
        /// </summary>
        public About()
        {
            InitializeComponent();
        }
    }
}