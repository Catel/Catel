﻿namespace $safeprojectname$.Views
{
    using Catel.Windows.Controls;
	
    /// <summary>
    /// Interaction logic for Home.xaml.
    /// </summary>
    public partial class Home : Page
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Home"/> class.
        /// </summary>
        public Home()
        {
            InitializeComponent();
        }
    }
}