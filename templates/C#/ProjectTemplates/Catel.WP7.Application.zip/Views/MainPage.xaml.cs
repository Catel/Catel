﻿namespace $safeprojectname$.Views
{
	using Catel.Phone.Controls;

    /// <summary>
    /// Interaction logic for MainPage.xaml.
    /// </summary>
    public partial class MainPage : PhoneApplicationPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}