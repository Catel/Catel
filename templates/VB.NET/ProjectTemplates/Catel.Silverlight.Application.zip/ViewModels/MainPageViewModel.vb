﻿Imports Catel.MVVM

Namespace ViewModels

	''' <summary>
	''' MainPage view model.
	''' </summary>
	Public Class MainPageViewModel
		Inherits ViewModelBase
		#Region "Fields"
		#End Region

		#Region "Constructors"
		''' <summary>
		''' Initializes a new instance of the <see cref="MainPageViewModel"/> class.
		''' </summary>
		Public Sub New()
		End Sub
		#End Region

		#Region "Properties"
		''' <summary>
		''' Gets the title of the view model.
		''' </summary>
		''' <value>The title.</value>
		Public Overrides ReadOnly Property Title() As String
			Get
				Return "View model title"
			End Get
		End Property

		' TODO: Register models with the vmpropmodel codesnippet
		' TODO: Register view model properties with the vmprop or vmpropviewmodeltomodel codesnippets
		#End Region

		#Region "Commands"
		' TODO: Register commands with the vmcommand or vmcommandwithcanexecute codesnippets
		#End Region

		#Region "Methods"
		' TODO: Create your methods here
		#End Region
	End Class
	
End Namespace