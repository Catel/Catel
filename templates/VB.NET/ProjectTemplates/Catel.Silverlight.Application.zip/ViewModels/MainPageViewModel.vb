﻿Imports Catel.MVVM

Namespace ViewModels

	''' <summary>
	''' MainPage view model.
	''' </summary>
	Public Class MainPageViewModel
		Inherits ViewModelBase

		''' <summary>
		''' Initializes a new instance of the <see cref="MainPageViewModel"/> class.
		''' </summary>
		Public Sub New()
		End Sub

		''' <summary>
		''' Gets the title of the view model.
		''' </summary>
		''' <value>The title.</value>
		Public Overrides ReadOnly Property Title() As String
			Get
				Return "$safeprojectname$"
			End Get
		End Property

	End Class
	
End Namespace