﻿Namespace Views

	''' <summary>
	''' Main page.
	''' </summary>
	Public Partial Class MainPage
		Inherits Catel.Windows.Controls.UserControl
		''' <summary>
		''' Initializes a new instance of the <see cref="MainPage"/> class.
		''' </summary>
		Public Sub New()
			InitializeComponent()
		End Sub
	End Class
	
End Namespace