﻿Imports System.Collections.Generic
Imports System.Collections.ObjectModel
Imports Catel.Data
Imports Catel.MVVM
Imports Catel.MVVM.Services
Imports $safeprojectname$.Models

Namespace ViewModels

	Public Class MainPageViewModel
		Inherits ViewModelBase
		#Region "Fields"
		#End Region

		#Region "Constructors"
		''' <summary>
		''' Initializes a new instance of the <see cref="MainPageViewModel"/> class.
		''' </summary>
		Public Sub New()
			MyBase.New()
			Items = New ObservableCollection(Of ItemData)()
		End Sub
		#End Region

		#Region "Properties"
		''' <summary>
		''' Gets the title of the view model.
		''' </summary>
		''' <value>The title.</value>
		Public Overrides ReadOnly Property Title() As String
			Get
				Return "Page title"
			End Get
		End Property

		' TODO: Register models with the vmpropmodel codesnippet
		' TODO: Register view model properties with the vmprop or vmpropviewmodeltomodel codesnippets

		''' <summary>
		''' Gets or sets the collection of items.
		''' </summary>
		Public Property Items() As ObservableCollection(Of ItemData)
			Get
				Return GetValue(Of ObservableCollection(Of ItemData))(ItemsProperty)
			End Get
			Private Set
				SetValue(ItemsProperty, value)
			End Set
		End Property

		''' <summary>
		''' Register the Items property so it is known in the class.
		''' </summary>
		Public Shared ReadOnly ItemsProperty As PropertyData = RegisterProperty("Items", GetType(ObservableCollection(Of ItemData)))
		#End Region

		#Region "Commands"
		' TODO: Register commands with the vmcommand or vmcommandwithcanexecute codesnippets
		#End Region

		#Region "Methods"
		#End Region
	End Class

	Public Class DesignMainPageViewModel
		Inherits MainPageViewModel
		Public Sub New()
			' Design data
			Items.Add(New ItemData("Design data 1"))
			Items.Add(New ItemData("Design data 2"))
			Items.Add(New ItemData("Design data 3"))
			Items.Add(New ItemData("Design data 4"))
			Items.Add(New ItemData("Design data 5"))
		End Sub
	End Class
End Namespace
