﻿Imports Catel.Data

Namespace Models

	''' <summary>
	''' DataItem Data object class which fully supports serialization, property changed notifications,
	''' backwards compatibility and error checking.
	''' </summary>
	Public Class ItemData
		Inherits ModelBase
		#Region "Fields"
		#End Region

		#Region "Constructors"
		''' <summary>
		''' Initializes a new instance of the <see cref="ItemData"/> class.
		''' </summary>
		Public Sub New()
			Me.New(NameProperty.GetDefaultValue(Of String)())
		End Sub

		''' <summary>
		''' Initializes a new instance of the <see cref="ItemData"/> class.
		''' </summary>
		''' <param name="itemName">The name.</param>
		Public Sub New(itemName As String)
			Name = itemName
		End Sub
		#End Region

		#Region "Properties"
		''' <summary>
		''' Gets or sets the name.
		''' </summary>
		Public Property Name() As String
			Get
				Return GetValue(Of String)(NameProperty)
			End Get
			Set
				SetValue(NameProperty, value)
			End Set
		End Property

		''' <summary>
		''' Register the Name property so it is known in the class.
		''' </summary>
		Public Shared ReadOnly NameProperty As PropertyData = RegisterProperty("Name", GetType(String), String.Empty)
		#End Region

		#Region "Methods"
		#End Region
	End Class
	
End Namespace