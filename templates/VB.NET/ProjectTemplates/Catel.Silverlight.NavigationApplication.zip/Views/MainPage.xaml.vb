﻿Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Navigation

Namespace Views

	''' <summary>
	''' Main page.
	''' </summary>
	Public Partial Class MainPage
		Inherits UserControl
		''' <summary>
		''' Initializes a new instance of the <see cref="MainPage"/> class.
		''' </summary>
		Public Sub New()
			InitializeComponent()
		End Sub

		''' <summary>
		''' After the Frame navigates, ensure the HyperlinkButton representing the current page is selected
		''' </summary>
		Private Sub OnContentFrameNavigated(sender As Object, e As NavigationEventArgs)
			For Each child As UIElement In LinksStackPanel.Children
				Dim hb As HyperlinkButton = TryCast(child, HyperlinkButton)
				If hb IsNot Nothing AndAlso hb.NavigateUri IsNot Nothing Then
					If hb.NavigateUri.ToString().Equals(e.Uri.ToString()) Then
						VisualStateManager.GoToState(hb, "ActiveLink", True)
					Else
						VisualStateManager.GoToState(hb, "InactiveLink", True)
					End If
				End If
			Next
		End Sub

		''' <summary>
		''' If an error occurs during navigation, show an error window.
		''' </summary>		
		Private Sub OnContentFrameNavigationFailed(sender As Object, e As NavigationFailedEventArgs)
			e.Handled = True
			Dim errorWin As ChildWindow = New ErrorWindow(e.Uri)
			errorWin.Show()
		End Sub
	End Class
	
End Namespace
