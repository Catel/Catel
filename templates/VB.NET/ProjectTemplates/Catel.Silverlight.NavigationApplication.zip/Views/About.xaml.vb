﻿Namespace Views

	''' <summary>
	''' Main page.
	''' </summary>
	Public Partial Class About
		Inherits Catel.Windows.Controls.Page
		''' <summary>
		''' Initializes a new instance of the <see cref="About"/> class.
		''' </summary>
		Public Sub New()
			InitializeComponent()
		End Sub
	End Class
	
End Namespace