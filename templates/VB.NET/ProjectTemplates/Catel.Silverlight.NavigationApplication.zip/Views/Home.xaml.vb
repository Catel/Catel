﻿Namespace Views

	''' <summary>
	''' Main page.
	''' </summary>
	Public Partial Class Home
		Inherits Catel.Windows.Controls.Page
		''' <summary>
		''' Initializes a new instance of the <see cref="Home"/> class.
		''' </summary>
		Public Sub New()
			InitializeComponent()
		End Sub
	End Class
	
End Namespace