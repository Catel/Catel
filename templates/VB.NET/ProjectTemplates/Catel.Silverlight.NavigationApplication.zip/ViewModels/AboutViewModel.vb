﻿Imports System.Collections.Generic
Imports Catel.Data
Imports Catel.MVVM
Imports Catel.MVVM.Services

Namespace ViewModels

	''' <summary>
	''' About view model.
	''' </summary>
	Public Class AboutViewModel
		Inherits ViewModelBase
		
		''' <summary>
		''' Initializes a new instance of the <see cref="AboutViewModel"/> class.
		''' </summary>
		Public Sub New()
			NavigateToHomeViaViewModel = New Command(Of Object)(AddressOf OnNavigateToHomeViaViewModelExecute)
		End Sub

		''' <summary>
		''' Gets the title of the view model.
		''' </summary>
		''' <value>The title.</value>
		Public Overrides ReadOnly Property Title() As String
			Get
				Return "About"
			End Get
		End Property

		''' <summary>
		''' Gets or sets the navigation data.
		''' </summary>
		Public Property NavigationData() As String
			Get
				Return GetValue(Of String)(NavigationDataProperty)
			End Get
			Set
				SetValue(NavigationDataProperty, value)
			End Set
		End Property

		''' <summary>
		''' Register the NavigationData property so it is known in the class.
		''' </summary>
		Public Shared ReadOnly NavigationDataProperty As PropertyData = RegisterProperty("NavigationData", GetType(String))

		''' <summary>
		''' Gets the NavigateToHomeViaViewModel command.
		''' </summary>
		Public Property NavigateToHomeViaViewModel() As Command(Of Object)
			Get
				Return m_NavigateToHomeViaViewModel
			End Get
			Private Set
				m_NavigateToHomeViaViewModel = Value
			End Set
		End Property
		Private m_NavigateToHomeViaViewModel As Command(Of Object)

		''' <summary>
		''' Method to invoke when the NavigateToHomeViaViewModel command is executed.
		''' </summary>
		''' <param name="parameter">The parameter of the command.</param>
		Private Sub OnNavigateToHomeViaViewModelExecute(parameter As Object)
			Dim parameters = New Dictionary(Of String, Object)()
			parameters.Add("Data", "navigated from about")

			Dim navigationService = GetService(Of INavigationService)()
			navigationService.Navigate(Of HomeViewModel)(parameters)
		End Sub

		''' <summary>
		''' Called when the navigation has completed.
		''' </summary>
		''' <remarks>
		''' This should of course be a cleaner solution, but there is no other way to let a view-model
		''' know that navigation has completed. Another option is injection, but this would require every
		''' view-model for Windows Phone 7 to accept only the navigation context, which has actually nothing
		''' to do with the logic.
		''' <para/>
		''' It is also possible to use the <see cref="NavigationCompleted"/> event.
		''' </remarks>
		Protected Overrides Sub OnNavigationCompleted()
			NavigationData = String.Empty
			If NavigationContext.ContainsKey("Data") Then
				NavigationData = TryCast(NavigationContext("Data"), String)
			End If
		End Sub
	End Class
End Namespace
