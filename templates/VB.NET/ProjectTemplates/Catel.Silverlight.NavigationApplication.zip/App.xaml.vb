﻿Imports System.Windows
Imports System.Windows.Controls

Imports $safeprojectname$.Views

Imports Catel.IoC
Imports Catel.Logging
Imports Catel.Windows
 
Partial Public Class App
    Inherits Application

	Private Shared ReadOnly Log As ILog = LogManager.GetCurrentClassLogger()
	
    Public Sub New()
#if DEBUG
        LogManager.AddDebugListener()
#endif
	
        InitializeComponent()
		
		AddHandler Startup, AddressOf OnApplicationStartup
		AddHandler UnhandledException, AddressOf OnApplicationUnhandledException
    End Sub
    
    Private Sub OnApplicationStartup(ByVal o As Object, ByVal e As StartupEventArgs) Handles Me.Startup
		Log.Info "Starting application"
	
		' Want to improve performance? Uncomment the lines below. Note though that this will disable
		' some features. 
		'
		' For more information, see https://catelproject.atlassian.net/wiki/display/CTL/Performance+considerations
		
		' Log.Info "Improving performance"
		' Catel.Data.ModelBase.DefaultSuspendValidationValue = true			
		
        
		' TODO: Register custom types in the ServiceLocator
		'Log.Info "Registering custom types"
		'Dim serviceLocator = ServiceLocator.Default
		'serviceLocator.RegisterType(Of IMyInterface, IMyClass)()	
	
		StyleHelper.CreateStyleForwardersForDefaultStyles()

		RootVisual = New MainPage()	
    End Sub
    
    Private Sub Application_Exit(ByVal o As Object, ByVal e As EventArgs) Handles Me.Exit

    End Sub
    
    Private Sub OnApplicationUnhandledException(ByVal sender As object, ByVal e As ApplicationUnhandledExceptionEventArgs) Handles Me.UnhandledException

        ' If the app is running outside of the debugger then report the exception using
        ' the browser's exception mechanism. On IE this will display it a yellow alert 
        ' icon in the status bar and Firefox will display a script error.
        If Not System.Diagnostics.Debugger.IsAttached Then

            ' NOTE: This will allow the application to continue running after an exception has been thrown
            ' but not handled. 
            ' For production applications this error handling should be replaced with something that will 
            ' report the error to the website and stop the application.
            e.Handled = True
            Deployment.Current.Dispatcher.BeginInvoke(New Action(Of ApplicationUnhandledExceptionEventArgs)(AddressOf ReportErrorToDOM), e)
        End If
    End Sub

   Private Sub ReportErrorToDOM(ByVal e As ApplicationUnhandledExceptionEventArgs)

        Try
            Dim errorMsg As String = e.ExceptionObject.Message + e.ExceptionObject.StackTrace
            errorMsg = errorMsg.Replace(""""c, "'"c).Replace(ChrW(13) & ChrW(10), "\n")

            System.Windows.Browser.HtmlPage.Window.Eval("throw new Error(""Unhandled Error in Silverlight Application " + errorMsg + """);")
        Catch
        
        End Try
    End Sub
    
End Class
