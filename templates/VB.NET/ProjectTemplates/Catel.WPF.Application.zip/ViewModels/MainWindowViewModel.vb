﻿Imports Catel.MVVM

Namespace $safeprojectname$.ViewModels

	''' <summary>
	''' MainWindow view model.
	''' </summary>
	Public Class MainWindowViewModel
		Inherits ViewModelBase

		''' <summary>
		''' Initializes a new instance of the <see cref="MainWindowViewModel"/> class.
		''' </summary>
		Public Sub New()
		End Sub

		''' <summary>
		''' Gets the title of the view model.
		''' </summary>
		''' <value>The title.</value>
		Public Overrides ReadOnly Property Title() As String
			Get
				Return "View model title"
			End Get
		End Property
	End Class
	
End Namespace