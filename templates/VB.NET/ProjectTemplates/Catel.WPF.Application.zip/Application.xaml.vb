﻿Imports System.Windows
Imports System.Windows.Controls

Imports $safeprojectname$.Views

Imports Catel.IoC
Imports Catel.Logging
Imports Catel.Reflection
Imports Catel.Windows

Class Application

	Private Shared ReadOnly Log As ILog = LogManager.GetCurrentClassLogger()

	''' <summary>
	''' Raises the <see cref="E:System.Windows.Application.Startup"/> event.
	''' </summary>
	''' <param name="e">A <see cref="T:System.Windows.StartupEventArgs"/> that contains the event data.</param>
	Protected Overrides Sub OnStartup(e As StartupEventArgs)
#if DEBUG
        LogManager.AddDebugListener()
#endif
	
		Log.Info "Starting application"
	
		' To force the loading of all assemblies at startup, uncomment the lines below:
		
		'Log.Info "Preloading assemblies"
		'AppDomain.CurrentDomain.PreloadAssemblies()	
	
		' Want to improve performance? Uncomment the lines below. Note though that this will disable
		' some features. 
		'
		' For more information, see https://catelproject.atlassian.net/wiki/display/CTL/Performance+considerations
		
		' Log.Info "Improving performance"
		' Catel.Data.ModelBase.DefaultSuspendValidationValue = true			
		
        
		' TODO: Register custom types in the ServiceLocator
		'Log.Info "Registering custom types"
		'Dim serviceLocator = ServiceLocator.Default
		'serviceLocator.RegisterType(Of IMyInterface, IMyClass)()	
	
		StyleHelper.CreateStyleForwardersForDefaultStyles()

		Log.Info "Calling base.OnStartup"
		
		MyBase.OnStartup(e)
	End Sub
End Class