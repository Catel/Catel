﻿Imports ViewModels

Namespace $rootnamespace$
	''' <summary>
	''' Interaction logic for $safeitemname$.xaml
	''' </summary>
	Public Partial Class $safeitemname$
		Inherits Catel.Windows.DataWindow
		''' <summary>
		''' Initializes a new instance of the <see cref="$safeitemname$"/> class.
		''' </summary>
		Public Sub New()
			Me.New(Nothing)
		End Sub

		''' <summary>
		''' Initializes a new instance of the <see cref="$safeitemname$"/> class.
		''' </summary>
		''  <param name="viewModel">The view model to inject.</param>
		''' <remarks>
		''' This constructor can be used to use view-model injection.
		''' </remarks>
		Public Sub New(viewModel As $safeitemname$Model)
			MyBase.New(viewModel)
			InitializeComponent()
		End Sub
	End Class
End Namespace