﻿Imports Catel.MVVM

Namespace $rootnamespace$
	''' <summary>
	''' UserControl view model.
	''' </summary>
	Public Class $safeitemname$
		Inherits ViewModelBase
		''' <summary>
		''' Initializes a new instance of the <see cref="$safeitemname$"/> class.
		''' </summary>
		Public Sub New()
		End Sub

		''' <summary>
		''' Gets the title of the view model.
		''' </summary>
		''' <value>The title.</value>
		Public Overrides ReadOnly Property Title() As String
			Get
				Return "View model title"
			End Get
		End Property

		' TODO: Register models with the vmpropmodel codesnippet
		' TODO: Register view model properties with the vmprop or vmpropviewmodeltomodel codesnippets
		' TODO: Register commands with the vmcommand or vmcommandwithcanexecute codesnippets
	End Class
End Namespace