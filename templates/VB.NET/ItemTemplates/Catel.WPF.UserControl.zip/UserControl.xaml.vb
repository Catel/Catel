﻿Namespace $rootnamespace$
	''' <summary>
	''' Interaction logic for $safeitemname$.xaml.
	''' </summary>
	Public Partial Class $safeitemname$
		Inherits Catel.Windows.Controls.UserControl
		''' <summary>
		''' Initializes a new instance of the <see cref="$safeitemname$"/> class.
		''' </summary>
		Public Sub New()
			InitializeComponent()
		End Sub
	End Class
End Namespace